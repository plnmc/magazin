<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_6232eaff79c9ccb6c1a66e5a75a212d5'] = 'Block Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_95d17a0a1b5ea2de13a3565ed400ebbb'] = 'Block mit Verkaufshits des Shops hinzufügen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Bestätigung';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Aktualisierte Einstellungen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_530c88f8210e022b39128e3f0409bbcf'] = 'Block immer anzeigen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_a8a670d89a6d2f3fa59942fc591011ef'] = 'Block anzeigen, auch wenn kein Produkt verfügbar ist.';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Alle Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Momentan keine Verkaufshits';
