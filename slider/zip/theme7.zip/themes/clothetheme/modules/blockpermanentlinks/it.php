<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contatto';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'Mappa del sito';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'segnalibro';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_39355c36cfd8f1d048a1f84803963534'] = 'Blocco link permanenti';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_3a3bf29ed9ddeb6210a731d2b1454df2'] = 'Aggiunge un blocco che visualizza i link permanenti come mappa del sito, contatti, ecc';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_e1da49db34b0bdfdddaba2ad6552f848'] = 'Mappa del sito';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contatto';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_05eb51862bc90ef24d04f3f1d8be5274'] = 'Segna questa pagina';
