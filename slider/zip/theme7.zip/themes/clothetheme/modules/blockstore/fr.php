<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}prestashop>blockstore_50d335623ef166aeea8da2a3c2c63a3e'] = 'Bloc magasins';
$_MODULE['<{blockstore}prestashop>blockstore_7118171dfc2981fd3d7f3aab97fb572d'] = 'Affiche un bloc avec un lien vers la liste des magasins';
$_MODULE['<{blockstore}prestashop>blockstore_f32a6c9e15dd20152ee8b14c7f94b040'] = 'image invalide';
$_MODULE['<{blockstore}prestashop>blockstore_4dd95964f5b02106aeaa2dbf3e9d3c5e'] = 'une erreur s\'est produite lors de l\'envoi';
$_MODULE['<{blockstore}prestashop>blockstore_7ccf58c950043c9fbfed668df13ce608'] = 'Paramètres mis à jour';
$_MODULE['<{blockstore}prestashop>blockstore_dbd41b964013caae2d73220618b5ae90'] = 'Configuration du block magasins';
$_MODULE['<{blockstore}prestashop>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Image du block';
$_MODULE['<{blockstore}prestashop>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Changer l\'image:';
$_MODULE['<{blockstore}prestashop>blockstore_f6f1e75fd6d515138c3c802459aa384d'] = 'l\'image sera affiché au format 174x115';
$_MODULE['<{blockstore}prestashop>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos magasins';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Découvrez nos magasins';
