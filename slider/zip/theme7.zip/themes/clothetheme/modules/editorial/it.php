<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{editorial}prestashop>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Editor della home page';
$_MODULE['<{editorial}prestashop>editorial_d02076897ed05399e22a0597404924ad'] = 'Un modulo editor di testo per la tua home page';
$_MODULE['<{editorial}prestashop>editorial_7fc8b5e7597368c070f5bc87c719dcc1'] = 'Non è possibile effettuare questa azione';
$_MODULE['<{editorial}prestashop>editorial_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Errore durante il caricamento delle immagini.';
$_MODULE['<{editorial}prestashop>editorial_462390017ab0938911d2d4e964c0cab7'] = 'Impostazioni aggiornate con successo';
$_MODULE['<{editorial}prestashop>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Titolo principale';
$_MODULE['<{editorial}prestashop>editorial_7496c27605d7ac3462a5dab8ecf1b569'] = 'Appare nella parte superiore della home page';
$_MODULE['<{editorial}prestashop>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Sottotitolo';
$_MODULE['<{editorial}prestashop>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Testo introduttivo';
$_MODULE['<{editorial}prestashop>editorial_930919b6f854a62e62401e3e76377cc1'] = 'Testo a tua scelta; ad esempio, spiega la tua missione, evidenzia un nuovo prodotto, o descrivi un evento recente';
$_MODULE['<{editorial}prestashop>editorial_78587f196180054fcb797d40f4a86f10'] = 'Logo della home page ';
$_MODULE['<{editorial}prestashop>editorial_b18c29b8470190a02813415a04a2191f'] = 'Dimensioni file';
$_MODULE['<{editorial}prestashop>editorial_729a51874fe901b092899e9e8b31c97a'] = 'Sei sicuro?';
$_MODULE['<{editorial}prestashop>editorial_f2a6c498fb90ee345d997f888fce3b18'] = 'Elimina';
$_MODULE['<{editorial}prestashop>editorial_f85e125f2a9ebcd47f420c94b535f50a'] = 'Apparirà accanto al testo introduttivo sopra';
$_MODULE['<{editorial}prestashop>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Link logo home page';
$_MODULE['<{editorial}prestashop>editorial_62f6077d6d15a35ff4929a225205892f'] = 'Link utilizzato sul secondo logo';
$_MODULE['<{editorial}prestashop>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Sottotitolo logo home page ';
$_MODULE['<{editorial}prestashop>editorial_c260ede55f0be17068302e7f842802f3'] = 'Aggiorna l\'editor';
