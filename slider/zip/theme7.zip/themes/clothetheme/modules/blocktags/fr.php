<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Bloc tags';
$_MODULE['<{blocktags}prestashop>blocktags_a332910d45d955dad6c84817fe478e95'] = 'Ajoute un bloc contenant les tags et un lien vers la recherche correspondante';
$_MODULE['<{blocktags}prestashop>blocktags_4c1ef2cab0e711084a14f3d367a13c54'] = 'Vous devez remplir le champs \"tags affichés\"';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Nombre invalide.';
$_MODULE['<{blocktags}prestashop>blocktags_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmer';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocktags}prestashop>blocktags_a2701a006c71c9097d80ea1ddaea8fa9'] = 'Tags affichés';
$_MODULE['<{blocktags}prestashop>blocktags_ba1ebc23c8fd03e9b97da2f856f70765'] = 'Nombre de tags affichés dans le bloc';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus à propos de';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Aucun tag spécifié pour le moment';
