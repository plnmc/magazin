<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}prestashop>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Blocco pubblicità';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_a7339a98fd0ebea5ed982f92eed11c70'] = 'Aggiunge un blocco per visualizzare un messaggio pubblicitario';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_226ed577d0eff50725be6447bcd5a2f0'] = 'Errore sposta il file caricato';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_6e7be6d836003f069c00cd217660913b'] = 'Pubblicità blocco di configurazione';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_2ce5fc289845ce826261032b9c6749ea'] = 'Pubblicità';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_93d5113a3d56b880522391fd049128f6'] = 'Pubblicità immagine';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_706bebc78ad992a07e4c1ce0f39def81'] = 'nessuna immagine';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_83b5a65e518c21ed0a5f2b383dd9b617'] = 'elimina l\'immagine';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_8c38cf08a0d0a01bd44c682479432350'] = 'Cambia immagine';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_56d9dfa26d7848a3fbcd2ae3091d38d9'] = 'immagine verrà visualizzata come 155x163';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Immagine Link';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_f9ab05454998236921a6b0e281fae632'] = 'convalidare';
