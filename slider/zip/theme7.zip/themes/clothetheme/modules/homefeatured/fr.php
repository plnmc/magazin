<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}prestashop>homefeatured_cd2c2dc24eaf11ba856da4a2e2a248be'] = 'Produits phares sur la page d\'accueil';
$_MODULE['<{homefeatured}prestashop>homefeatured_bedd0eb227b31705fce270fe1ec5639f'] = 'Affiche les produits phares au centre de votre page d\'accueil';
$_MODULE['<{homefeatured}prestashop>homefeatured_dd0de17e8450a0fd3248b19c4a4f803b'] = 'Nombre de produit invalide';
$_MODULE['<{homefeatured}prestashop>homefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{homefeatured}prestashop>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{homefeatured}prestashop>homefeatured_6df1f9b5662398a551a2c9185b26638a'] = 'Pour ajouter des produits à votre page d\'accueil, ajoutez-les simplement à la catégorie \"Accueil\" du catalogue.';
$_MODULE['<{homefeatured}prestashop>homefeatured_3c230497560c52be92b93c65de9defc9'] = 'Nombre de produits';
$_MODULE['<{homefeatured}prestashop>homefeatured_5bc8290012fcc597689ef8959c2fc969'] = 'Le nombre de produits affichés sur la page d\'accueil (défaut : 10)';
$_MODULE['<{homefeatured}prestashop>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{homefeatured}prestashop>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Produits phares';
$_MODULE['<{homefeatured}prestashop>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Plus d\'infos';
$_MODULE['<{homefeatured}prestashop>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Plus d\'infos';
$_MODULE['<{homefeatured}prestashop>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{homefeatured}prestashop>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Aucun produit phare';
