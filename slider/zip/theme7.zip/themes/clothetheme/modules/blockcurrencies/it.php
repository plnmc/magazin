<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_f7a31ae8f776597d4282bd3b1013f08b'] = 'Blocco valuta';
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_d06c31fa4b0b56c2a61aa4dd7b632767'] = 'Aggiunge un blocco per la selezione di una valuta';
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'Valuta';
