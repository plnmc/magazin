<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockrss}prestashop>blockrss_2516c13a12d3dbaf4efa88d9fce2e7da'] = 'Bloc flux RSS';
$_MODULE['<{blockrss}prestashop>blockrss_04396664ce529aa4204b0f7ad753fad1'] = 'Ajoute un bloc avec les messages d\'un flux RSS';
$_MODULE['<{blockrss}prestashop>blockrss_9680162225162baf2a085dfdc2814deb'] = 'Flux RSS';
$_MODULE['<{blockrss}prestashop>blockrss_6706b6d8ba45cc4f0eda0506ba1dc3c8'] = 'URL du flux invalide';
$_MODULE['<{blockrss}prestashop>blockrss_36ed65ce17306e812fd68d9f634c0c57'] = 'Titre invalide';
$_MODULE['<{blockrss}prestashop>blockrss_1b3d34e25aef32a3c8daddfff856577f'] = 'Nombre de flux invalide';
$_MODULE['<{blockrss}prestashop>blockrss_606a95aefd4296583b685aa039f01681'] = 'Vous avez sélectionné une flux RSS de votre propre site, il s\'agit très probablement d\'une erreur ! Choisissez une autre URL (ex : http://news.google.com/?output=rss) sauf si vous êtes sûr de votre action';
$_MODULE['<{blockrss}prestashop>blockrss_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockrss}prestashop>blockrss_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockrss}prestashop>blockrss_b22c8f9ad7db023c548c3b8e846cb169'] = 'Titre du bloc';
$_MODULE['<{blockrss}prestashop>blockrss_2343a40bdffd8c7a6317b6d98c2b1042'] = 'Créez un titre pour le block (par défaut : \'Flux RSS\')';
$_MODULE['<{blockrss}prestashop>blockrss_402d00ca8e4f0fff26fc24ee9ab8e82b'] = 'Ajouter une URL';
$_MODULE['<{blockrss}prestashop>blockrss_eb26a56cc4c9ae20bc55c887773bddfd'] = 'Ajouter l\'url du flux que vous souhaitez utiliser';
$_MODULE['<{blockrss}prestashop>blockrss_ff9aa540e20285875ac8b190a3cb7ccf'] = 'Nombre de messages affichés';
$_MODULE['<{blockrss}prestashop>blockrss_f33725e23a017705ad35897e849a4db4'] = 'Nombre de messages affichés par le bloc (défaut : 5)';
$_MODULE['<{blockrss}prestashop>blockrss_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{blockrss}prestashop>blockrss_10fd25dcd3353c0ba3731d4a23657f2e'] = 'Aucun flux RSS ajouté';
