<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockhomeslideshow}prestashop>blockhomeslideshow_2bc460413bdb04a2958b28e2d492fe96'] = 'Accueil Diaporama Block';
$_MODULE['<{blockhomeslideshow}prestashop>blockhomeslideshow_6069ed85dc1e64dd9c04694977cc52de'] = 'Ajoute un diaporama à la page d&#39;accueil.';
