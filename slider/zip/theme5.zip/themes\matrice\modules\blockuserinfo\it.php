<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Blocco info utente ';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Aggiungi un blocco che visualizza le informazioni sul cliente';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Benvenuti';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Fammi uscire';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Esci';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_bffe9a3c9a7e00ba00a11749e022d911'] = 'Entra';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_12641546686fe11aaeb3b3c43a18c1b3'] = 'Il tuo carrello';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_7fc68677a16caa0f02826182468617e6'] = 'Carrello:';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_f5bf48aa40cad7891eb709fcf1fde128'] = 'prodotto';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_86024cad1e83101d97359d7351051156'] = 'prodotti';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(vuoto)';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Il tuo account';
