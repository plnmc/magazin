<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_891ad007e2e9f2d55be6669cd9abc7a0'] = 'plus';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Pas encore de meilleure vente';
