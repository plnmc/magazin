<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cashondelivery}matrice>cashondelivery_1f9497d3e8bac9b50151416f04119cec'] = 'Nachnahme (COD)';
$_MODULE['<{cashondelivery}matrice>cashondelivery_7a3ef27eb0b1895ebf263ad7dd949fb6'] = 'Zahlungen per Nachnahme akzeptieren ';
$_MODULE['<{cashondelivery}matrice>confirmation_2e2117b7c81aa9ea6931641ea2c6499f'] = 'Ihre Bestellung von';
$_MODULE['<{cashondelivery}matrice>confirmation_75fbf512d744977d62599cc3f0ae2bb4'] = 'ist abgeschlossen.';
$_MODULE['<{cashondelivery}matrice>confirmation_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Sie haben die Nachnahme-Methode gewählt.';
$_MODULE['<{cashondelivery}matrice>confirmation_e6dc7945b557a1cd949bea92dd58963e'] = 'Ihre Bestellung wird sehr bald geschickt werden.';
$_MODULE['<{cashondelivery}matrice>confirmation_0db71da7150c27142eef9d22b843b4a9'] = 'Bei Fragen oder für weitere Informationen, kontaktieren Sie bitte unseren';
$_MODULE['<{cashondelivery}matrice>confirmation_64430ad2835be8ad60c59e7d44e4b0b1'] = 'Kunden-Support';
$_MODULE['<{cashondelivery}matrice>payment_b7ada96a0da7ee7fb5371cca0b036d5c'] = 'Zahlung per Nachnahme (COD)';
$_MODULE['<{cashondelivery}matrice>payment_536dc7424180872c8c2488ae0286fb53'] = 'Sie bezahlen die Ware bei der Lieferung';
$_MODULE['<{cashondelivery}matrice>validation_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Versand';
$_MODULE['<{cashondelivery}matrice>validation_0c25b529b4d690c39b0831840d0ed01c'] = 'Bestellsumme';
$_MODULE['<{cashondelivery}matrice>validation_d538c5b86e9a71455ba27412f4e9ab51'] = 'Nachnahme-Zahlung (COD)';
$_MODULE['<{cashondelivery}matrice>validation_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Sie haben die Nachnahme-Methode gewählt.';
$_MODULE['<{cashondelivery}matrice>validation_e2867a925cba382f1436d1834bb52a1c'] = 'Der Gesamtbetrag Ihrer Bestellung beträgt';
$_MODULE['<{cashondelivery}matrice>validation_1f87346a16cf80c372065de3c54c86d9'] = '(Inkl. St.)';
$_MODULE['<{cashondelivery}matrice>validation_0881a11f7af33bc1b43e437391129d66'] = 'Bitte bestätigen Sie Ihre Bestellung durch Klicken auf \"Ich bestätige meine Bestellung\"';
$_MODULE['<{cashondelivery}matrice>validation_569fd05bdafa1712c4f6be5b153b8418'] = 'Andere Zahlungsmethoden';
$_MODULE['<{cashondelivery}matrice>validation_46b9e3665f187c739c55983f757ccda0'] = 'Ich bestätige meine Bestellung';
