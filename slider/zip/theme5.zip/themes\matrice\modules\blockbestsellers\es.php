<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_6232eaff79c9ccb6c1a66e5a75a212d5'] = 'Bloque de mejores ventas';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_56710978dfca4fcdf98977fcaa4a553f'] = 'Añadir un bloque para mostrar las mejores ventas de la tienda';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = '¡Lo más vendido!';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Los productos más vendidos';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'No hay productos más vendidos en este momento';
