<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}matrice>productscategory_db33983df8ef521000b0ab60dcb5a83f'] = 'Categoria prodotti';
$_MODULE['<{productscategory}matrice>productscategory_0157084bddd8b408e1cdaba00f54a009'] = 'Visualizza i prodotti della stessa categoria sulla pagina del prodotto';
$_MODULE['<{productscategory}matrice>productscategory_462390017ab0938911d2d4e964c0cab7'] = 'Impostazioni aggiornate con successo';
$_MODULE['<{productscategory}matrice>productscategory_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{productscategory}matrice>productscategory_b6bf131edd323320bac67303a3f4de8a'] = 'Mostra prezzo sui prodotti';
$_MODULE['<{productscategory}matrice>productscategory_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{productscategory}matrice>productscategory_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{productscategory}matrice>productscategory_70f9a895dc3273d34a7f6d14642708ec'] = 'Mostra il prezzo sui prodotti nel  blocco.';
$_MODULE['<{productscategory}matrice>productscategory_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{productscategory}matrice>productscategory_4aae87211f77aada2c87907121576cfe'] = 'altri prodotti della stessa categoria:';
$_MODULE['<{productscategory}matrice>productscategory_dd1f775e443ff3b9a89270713580a51b'] = 'Precedente';
$_MODULE['<{productscategory}matrice>productscategory_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{productscategory}matrice>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Successivo';
