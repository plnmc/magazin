<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Bloque de novedades';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_2dabfba3a3ebc0a7e4728f08ba165d1e'] = 'Mostrar el bloque con los nuevos productos añadidos';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_be3695bcf32c0086aa98108330d9bfa1'] = 'Debe rellenar el campo \"productos mostrados\"';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Número incorrecto';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmación';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_e451e6943bb539d1bd804d2ede6474b5'] = 'Productos mostrados';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_cc4bbebd6a8d2fb633a1dd8ceda3fc8d'] = 'Seleccione el número de productos a mostrar en este bloque';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Novedades';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Todas las novedades';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_2bc4c1efe10bba9f03fac3c59b4d2ae9'] = 'no hay nuevos productos en este momento';
