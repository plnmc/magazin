<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{crossselling}matrice>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'Les clients qui ont acheté ce produit ont également acheté...';
$_MODULE['<{crossselling}matrice>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
