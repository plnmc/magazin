<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Newsletter';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_eb3d6130739dd643ce3a7b27a5eb6af2'] = 'nouveautés, promos, réducs! inscrivez-vous notre lettre d\'information';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_416f61a2ce16586f8289d41117a2554e'] = 'votre e-mail';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_b26917587d98330d93f87808fc9d7267'] = 'Inscription';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_4182c8f19d40c7ca236a5f4f83faeb6b'] = 'Désinscription';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_a4d3b161ce1309df1c4e25df28694b7b'] = 'envoyez';
