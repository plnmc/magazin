<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{editorial}matrice>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Editor de textos página de inicio';
$_MODULE['<{editorial}matrice>editorial_1051bed4568ad9936781f20fb0536509'] = 'Un módulo de editor de texto para su página de inicio';
$_MODULE['<{editorial}matrice>editorial_5be920293db3e38c81330fd0798336b1'] = 'Campo html no válido, no puede utilizarse javascrip ';
$_MODULE['<{editorial}matrice>editorial_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Imposible escribir en el fichero del editor.';
$_MODULE['<{editorial}matrice>editorial_8072bc856691062b88d30354ab28a27a'] = 'No se puede cerrar el fichero del editor.';
$_MODULE['<{editorial}matrice>editorial_93314199c1f5be182040fd88370f44f4'] = 'Imposible actualizar el fichero del editor. Por favor, revise los permisos de escritura.';
$_MODULE['<{editorial}matrice>editorial_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Se ha producido un error meintras se subía la imagen.';
$_MODULE['<{editorial}matrice>editorial_eec34a41e732e39809721bab40e601cd'] = 'Su fichero de editor está vacío.';
$_MODULE['<{editorial}matrice>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Título principal';
$_MODULE['<{editorial}matrice>editorial_7496c27605d7ac3462a5dab8ecf1b569'] = 'Aparece a lo largo de la parte superior de la página de inicio';
$_MODULE['<{editorial}matrice>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Subtítulo';
$_MODULE['<{editorial}matrice>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Texto de introducción';
$_MODULE['<{editorial}matrice>editorial_0a9ce580a59ece76cad698332fd53887'] = 'Su texto; por ejm: explique su objetivo, destaque un nuevo producto, describa un evento..';
$_MODULE['<{editorial}matrice>editorial_22c2adcb89e2f2d9c5f6fe3731fad3b3'] = 'Imagen de página de inicio';
$_MODULE['<{editorial}matrice>editorial_f85e125f2a9ebcd47f420c94b535f50a'] = 'Aparecerá arriba, junto al texto de introducción';
$_MODULE['<{editorial}matrice>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Enlace del logo de página de inicio';
$_MODULE['<{editorial}matrice>editorial_62f6077d6d15a35ff4929a225205892f'] = 'Enlace usado en el segundo logo';
$_MODULE['<{editorial}matrice>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Subtítulo del logo de página de inicio';
$_MODULE['<{editorial}matrice>editorial_c260ede55f0be17068302e7f842802f3'] = 'Actualizar el editor';
