<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homecarousel}prestashop>homecarousel_d7566484171dfe7f71e54a83b8a0173a'] = 'MGC Carousel de produits sur la page d\'accueil';
$_MODULE['<{homecarousel}prestashop>homecarousel_06b62613f5f4c4a216a29089ba27095e'] = 'Affiche un carousel de produits sur l\'accueil de votre boutique';
$_MODULE['<{homecarousel}prestashop>homecarousel_ced2b9f1aad1f8a5b351a3120e4b1212'] = 'Nombre de produits invalide';
$_MODULE['<{homecarousel}prestashop>homecarousel_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{homecarousel}prestashop>homecarousel_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{homecarousel}prestashop>homecarousel_6ac2849c4b90cb39b442bc65984ef5e5'] = 'Scroll automatique';
$_MODULE['<{homecarousel}prestashop>homecarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homecarousel}prestashop>homecarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homecarousel}prestashop>homecarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homecarousel}prestashop>homecarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homecarousel}prestashop>homecarousel_7f7b98adafbfc4a0c0cb378303ad2e04'] = 'Intervalle entre deux scroll';
$_MODULE['<{homecarousel}prestashop>homecarousel_be3b18702acdccb05cce80385e05ca07'] = 'Temps entre chaque déplacement du carousel';
$_MODULE['<{homecarousel}prestashop>homecarousel_019883e4d3eec72118f2ab7caf79c3a3'] = 'Nombre de produits dans le carousel';
$_MODULE['<{homecarousel}prestashop>homecarousel_7081e77aac77289df7184362d95bb239'] = 'Le nombre de produits contenus par le carousel (défaut: 20)';
$_MODULE['<{homecarousel}prestashop>homecarousel_79be2d3ef6afa403b739e100c465c641'] = 'Nombre de produits visible';
$_MODULE['<{homecarousel}prestashop>homecarousel_1d48908165cc33dbd6f2250679372efe'] = 'Le nombre de produits de la partie visible du carousel';
$_MODULE['<{homecarousel}prestashop>homecarousel_e6fdefae576fb9c7c96d7461ec9d8e6f'] = 'Nomnbre de produits du décalage';
$_MODULE['<{homecarousel}prestashop>homecarousel_1c8f0b008978b16c4af20e2b43f2ac08'] = 'Correspond au nombre de produits correspondant au décalage à chaque déplacement du carousel';
$_MODULE['<{homecarousel}prestashop>homecarousel_4368703f6a602426ad630d2a3c940278'] = 'Type d\'image';
$_MODULE['<{homecarousel}prestashop>homecarousel_b87dbb93c0d6bb734f044e0d84baa1f6'] = 'Sélectionnez le type d\'image à utiliser pour le carousel';
$_MODULE['<{homecarousel}prestashop>homecarousel_c71ebaf7b7d39340ca476d5c52c59c07'] = 'Afficher le nom du produit';
$_MODULE['<{homecarousel}prestashop>homecarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homecarousel}prestashop>homecarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homecarousel}prestashop>homecarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homecarousel}prestashop>homecarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homecarousel}prestashop>homecarousel_3d2e6ee477aed42a72e35343ad288118'] = 'Afficher le prix';
$_MODULE['<{homecarousel}prestashop>homecarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homecarousel}prestashop>homecarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homecarousel}prestashop>homecarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homecarousel}prestashop>homecarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homecarousel}prestashop>homecarousel_af86096e14f4f3d4a7bed1c67d7a10ca'] = 'Catégories de la boutique à exclure';
$_MODULE['<{homecarousel}prestashop>homecarousel_0913f364b8fdaba1c50e03cb4e030222'] = 'Sélectionnez les catégories que vous souhaitez exclure du carousel (Conservez la touche CTRL appuyée pour en sélectionner plusieurs)';
$_MODULE['<{homecarousel}prestashop>homecarousel_0f4eda7645a471f0ccfd76b0c0e68656'] = 'Choix de l\'ordre';
$_MODULE['<{homecarousel}prestashop>homecarousel_c2ee1e1ca3418cc3720678990629d771'] = 'Pas d\'ordre - Ordre du Gestionnaire Admin => Catalogue -> Position';
$_MODULE['<{homecarousel}prestashop>homecarousel_64663f4646781c9c0110838b905daa23'] = 'Aléatoire';
$_MODULE['<{homecarousel}prestashop>homecarousel_4e4bbdbc0a0a101a7ef339fb9f06f4de'] = 'Prix Croissants';
$_MODULE['<{homecarousel}prestashop>homecarousel_288ee38bd237b6f2796f5a2cf7b715d6'] = 'Prix Décroissants';
$_MODULE['<{homecarousel}prestashop>homecarousel_e5d6ba7605f8724be3a101ab348641ea'] = 'Derniers mis à jour en premier';
$_MODULE['<{homecarousel}prestashop>homecarousel_bd72b1345884f6b3c884e4807ba8ff02'] = 'Derniers ajouts en premier';
$_MODULE['<{homecarousel}prestashop>homecarousel_a0ee51ab33d5ba89aafaa01217622395'] = 'Alphabétique';
$_MODULE['<{homecarousel}prestashop>homecarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{homecarousel}prestashop>homecarousel_5650889ba0a7166c9fcc68672d8b381c'] = 'Aucuns produits dans le Carousel';

?>
