<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsdata}prestashop>statsdata_a51950bf91ba55cd93a33ce3f8d448c2'] = 'Récupération des données statistiques';
$_MODULE['<{statsdata}prestashop>statsdata_974ccf59b041ae66afa975f609368573'] = 'Ce module doit être activé pour bénéficier des statistiques';
$_MODULE['<{statsdata}prestashop>statsdata_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{statsdata}prestashop>statsdata_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuration';
$_MODULE['<{statsdata}prestashop>statsdata_1a5b75c4be3c0100c99764b21e844cc8'] = 'Enregistrer les pages vues pour chaque client';
$_MODULE['<{statsdata}prestashop>statsdata_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{statsdata}prestashop>statsdata_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{statsdata}prestashop>statsdata_1ef5adaa7eef1a44e4cb6ce3fb61f5f5'] = 'Les pages vues des clients consomment beaucoup de ressources processeur et d\'espace en base de données.';
$_MODULE['<{statsdata}prestashop>statsdata_dd8289e220ec0de9a8b99adc7f9014b1'] = 'Enregistrer les pages vues globales';
$_MODULE['<{statsdata}prestashop>statsdata_6511e0043f774246017a4c255e1e10c3'] = 'Les pages vues nécessitent moins de ressources que le détail par client, mais en nécessitent néanmoins pas mal.';
$_MODULE['<{statsdata}prestashop>statsdata_48f08588e7f264b5ea1e7ea56ed768f6'] = 'Détection des plug-ins';
$_MODULE['<{statsdata}prestashop>statsdata_54e5f8bdd6c51a73d79ed702cdc9ac05'] = 'La détection des plug-ins charge un fichier javascript de 20ko supplémentaire pour les nouveaux visiteurs.';
$_MODULE['<{statsdata}prestashop>statsdata_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
