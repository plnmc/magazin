<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Bloc fabricant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_9859921e6d3733788e09599adb681dcd'] = 'Ajoute un bloc avec les fabricants';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'Nombre d\'éléments invalide';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bb30aac3161f999a357af767ce2fd7ec'] = 'Merci d\'activer au moins un affichage de liste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'Utiliser une liste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Afficher';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_6a7f245843454cf4f28ad7c5e2572aa2'] = 'éléments';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2e5acd674f7f821a81e99ed01d5305d1'] = 'Affiche les fabricants sous forme de liste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'Utiliser un menu déroulant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f68d82d608d94a571e0984a0288595e0'] = 'Affiche les fabricants dans un menu déroulant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricants';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus à propos de';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Tous les fabricants';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Aucun fabricant';
