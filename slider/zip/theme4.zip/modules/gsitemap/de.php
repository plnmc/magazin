<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Generieren Sie Ihre Google Sitemap-Datei';
$_MODULE['<{gsitemap}prestashop>gsitemap_5bbdad908e423585a7ecc6b61b66b313'] = 'Kann nicht erstellt werden';
$_MODULE['<{gsitemap}prestashop>gsitemap_09fa1e865bdcf4d3215d5b0005b93154'] = 'sitemap.xml Datei.';
$_MODULE['<{gsitemap}prestashop>gsitemap_5a517cec50ac8e742f6583c6c404c4e9'] = 'Sitemap-Datei erfolgreich erzeugt';
$_MODULE['<{gsitemap}prestashop>gsitemap_0a6ee1a4f10278211d74152e633d0ed0'] = 'Fehler beim Erstellen der Sitemap-Datei';
$_MODULE['<{gsitemap}prestashop>gsitemap_eb175747116b689caadea1b84202f513'] = 'Ihr Google-Sitemap-Datei ist online unter folgender Adresse:';
$_MODULE['<{gsitemap}prestashop>gsitemap_39d616ecc73e174052f1877ac2b3c853'] = 'Aktualisierung:';
$_MODULE['<{gsitemap}prestashop>gsitemap_b908c2f34052b5276e0bf50f0e042211'] = 'Dateigröße:';
$_MODULE['<{gsitemap}prestashop>gsitemap_3f69f5c6c3c90eee482f28ae77390cb9'] = 'Indizierte Seiten:';
$_MODULE['<{gsitemap}prestashop>gsitemap_b8cb67a25f16d9000d8c974e30441b59'] = 'Die Sitemap enthält auch Produkte der nicht aktivierten Kategorien';
$_MODULE['<{gsitemap}prestashop>gsitemap_60ee4e03c30c4827c80eb31bfd27130d'] = 'Die Sitemap enthält auch CMS-Seiten die nicht in einem CMS-Block sind';
$_MODULE['<{gsitemap}prestashop>gsitemap_8103220a578f92ec726809c3d47adc6e'] = 'Sitemap-Datei erzeugen';
$_MODULE['<{gsitemap}prestashop>gsitemap_0033cf1fdbd4354facfaa51f6f0de6a4'] = 'Sitemap-Datei aktualisieren';
$_MODULE['<{gsitemap}prestashop>gsitemap_f5a592018c8b55d2c968515ad7c58c91'] = 'Search Engine Optimization';
$_MODULE['<{gsitemap}prestashop>gsitemap_4ff2e716a7d06ce5274b4090b39abad3'] = 'Siehe';
$_MODULE['<{gsitemap}prestashop>gsitemap_8334797b9b3383d4f48d98178b8845ea'] = 'diese Seite';
$_MODULE['<{gsitemap}prestashop>gsitemap_abf27597777430142de13ed6eea36d75'] = 'für weitere Informationen';
