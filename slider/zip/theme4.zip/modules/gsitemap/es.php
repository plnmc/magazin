<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Genere su fichero de Google Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_5bbdad908e423585a7ecc6b61b66b313'] = 'Creación imposible';
$_MODULE['<{gsitemap}prestashop>gsitemap_09fa1e865bdcf4d3215d5b0005b93154'] = 'fichero sitemap.xml';
$_MODULE['<{gsitemap}prestashop>gsitemap_5a517cec50ac8e742f6583c6c404c4e9'] = 'El fichero sitemap fue generado correctamente';
$_MODULE['<{gsitemap}prestashop>gsitemap_0a6ee1a4f10278211d74152e633d0ed0'] = 'Error mientras se creaba el fichero sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_eb175747116b689caadea1b84202f513'] = 'Su fichero de google sitemap está online en la siguiente dirección:';
$_MODULE['<{gsitemap}prestashop>gsitemap_39d616ecc73e174052f1877ac2b3c853'] = 'Actualizar:';
$_MODULE['<{gsitemap}prestashop>gsitemap_b908c2f34052b5276e0bf50f0e042211'] = 'Tamaño';
$_MODULE['<{gsitemap}prestashop>gsitemap_3f69f5c6c3c90eee482f28ae77390cb9'] = 'Páginas Indexadas:';
$_MODULE['<{gsitemap}prestashop>gsitemap_b8cb67a25f16d9000d8c974e30441b59'] = 'Mapa del sitio también incluye productos de las categorías de inactivos';
$_MODULE['<{gsitemap}prestashop>gsitemap_60ee4e03c30c4827c80eb31bfd27130d'] = 'Mapa del sitio también incluye páginas de CMS que no están en un bloque de CMS';
$_MODULE['<{gsitemap}prestashop>gsitemap_8103220a578f92ec726809c3d47adc6e'] = 'Generar fichero Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_0033cf1fdbd4354facfaa51f6f0de6a4'] = 'Actualizar fichero Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_f5a592018c8b55d2c968515ad7c58c91'] = 'Optimizar Motor de Búsqueda';
$_MODULE['<{gsitemap}prestashop>gsitemap_4ff2e716a7d06ce5274b4090b39abad3'] = 'Lea';
$_MODULE['<{gsitemap}prestashop>gsitemap_8334797b9b3383d4f48d98178b8845ea'] = 'esta página';
$_MODULE['<{gsitemap}prestashop>gsitemap_abf27597777430142de13ed6eea36d75'] = 'para más información';
