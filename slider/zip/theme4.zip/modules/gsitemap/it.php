<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Genera il tuo file sitemap di Google';
$_MODULE['<{gsitemap}prestashop>gsitemap_5bbdad908e423585a7ecc6b61b66b313'] = 'Non è possibile creare';
$_MODULE['<{gsitemap}prestashop>gsitemap_09fa1e865bdcf4d3215d5b0005b93154'] = 'file sitemap.xml.';
$_MODULE['<{gsitemap}prestashop>gsitemap_5a517cec50ac8e742f6583c6c404c4e9'] = 'File Sitemap generato con successo';
$_MODULE['<{gsitemap}prestashop>gsitemap_0a6ee1a4f10278211d74152e633d0ed0'] = 'Errore durante la creazione del file sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_eb175747116b689caadea1b84202f513'] = 'Il tuo file sitemap di Google è online al seguente indirizzo:';
$_MODULE['<{gsitemap}prestashop>gsitemap_39d616ecc73e174052f1877ac2b3c853'] = 'Aggiornamento:';
$_MODULE['<{gsitemap}prestashop>gsitemap_b908c2f34052b5276e0bf50f0e042211'] = 'Dimensioni:';
$_MODULE['<{gsitemap}prestashop>gsitemap_3f69f5c6c3c90eee482f28ae77390cb9'] = 'Pagine indicizzate:';
$_MODULE['<{gsitemap}prestashop>gsitemap_a0548d857c8e9fcfd2b3c8e08d231456'] = 'Sitemap contiene tutti i prodotti';
$_MODULE['<{gsitemap}prestashop>gsitemap_570b9e0ce727cb56ff261113fa1c4eba'] = 'Default, solo i prodotti delle categorie attive sono inclusi nel Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_bbb0ad1beeb2e94661f89f8edfc79322'] = 'Sitemap contiene tutte le pagine CMS';
$_MODULE['<{gsitemap}prestashop>gsitemap_8a1b79d3b66d3234795649a69cf86410'] = 'Default, solo le pagine CMS nel blocco CMS sono inclusi nel Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_8103220a578f92ec726809c3d47adc6e'] = 'Genera file sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_0033cf1fdbd4354facfaa51f6f0de6a4'] = 'Aggiornamento file sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_f5a592018c8b55d2c968515ad7c58c91'] = 'Search Engine Optimization';
$_MODULE['<{gsitemap}prestashop>gsitemap_4ff2e716a7d06ce5274b4090b39abad3'] = 'Vedi';
$_MODULE['<{gsitemap}prestashop>gsitemap_8334797b9b3383d4f48d98178b8845ea'] = 'questa pagina';
$_MODULE['<{gsitemap}prestashop>gsitemap_abf27597777430142de13ed6eea36d75'] = 'per maggiori informazioni';

?>