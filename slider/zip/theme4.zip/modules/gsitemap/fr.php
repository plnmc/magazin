<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Génère votre fichier sitemap pour Google';
$_MODULE['<{gsitemap}prestashop>gsitemap_5bbdad908e423585a7ecc6b61b66b313'] = 'Impossible de créer';
$_MODULE['<{gsitemap}prestashop>gsitemap_09fa1e865bdcf4d3215d5b0005b93154'] = 'sitemap.xml.';
$_MODULE['<{gsitemap}prestashop>gsitemap_5a517cec50ac8e742f6583c6c404c4e9'] = 'Fichier Sitemap généré avec succès';
$_MODULE['<{gsitemap}prestashop>gsitemap_0a6ee1a4f10278211d74152e633d0ed0'] = 'Erreur durant la création du fichier Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_eb175747116b689caadea1b84202f513'] = 'Votre fichier Google Sitemap est en ligne à l\'adresse suivante :';
$_MODULE['<{gsitemap}prestashop>gsitemap_39d616ecc73e174052f1877ac2b3c853'] = 'Mise à jour';
$_MODULE['<{gsitemap}prestashop>gsitemap_b908c2f34052b5276e0bf50f0e042211'] = 'Taille du fichier';
$_MODULE['<{gsitemap}prestashop>gsitemap_3f69f5c6c3c90eee482f28ae77390cb9'] = 'Nombre de pages indexées';
$_MODULE['<{gsitemap}prestashop>gsitemap_b8cb67a25f16d9000d8c974e30441b59'] = 'Le Sitemap inclus également les produits des catégories inactives';
$_MODULE['<{gsitemap}prestashop>gsitemap_60ee4e03c30c4827c80eb31bfd27130d'] = 'Le Sitemap inclus également les pages CMS qui ne sont pas dans un bloc de CMS';
$_MODULE['<{gsitemap}prestashop>gsitemap_8103220a578f92ec726809c3d47adc6e'] = 'Générer le fichier sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_0033cf1fdbd4354facfaa51f6f0de6a4'] = 'Mettre à jour le fichier sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_f5a592018c8b55d2c968515ad7c58c91'] = 'Optimisation pour les moteurs de recherche (SEO)';
$_MODULE['<{gsitemap}prestashop>gsitemap_4ff2e716a7d06ce5274b4090b39abad3'] = 'Voir';
$_MODULE['<{gsitemap}prestashop>gsitemap_8334797b9b3383d4f48d98178b8845ea'] = 'cette page';
$_MODULE['<{gsitemap}prestashop>gsitemap_abf27597777430142de13ed6eea36d75'] = 'pour plus d\'informations';
