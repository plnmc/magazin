<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}prestashop>homefeatured_cd2c2dc24eaf11ba856da4a2e2a248be'] = 'Productos Destacados en la Página de inicio';
$_MODULE['<{homefeatured}prestashop>homefeatured_bedd0eb227b31705fce270fe1ec5639f'] = 'Mostrar Productos Destacados en el centro de su página de inicio';
$_MODULE['<{homefeatured}prestashop>homefeatured_dd0de17e8450a0fd3248b19c4a4f803b'] = 'Número de productos no válido';
$_MODULE['<{homefeatured}prestashop>homefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{homefeatured}prestashop>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{homefeatured}prestashop>homefeatured_6df1f9b5662398a551a2c9185b26638a'] = 'Para añadir productos a su página de inicio, sólo tiene que añadirlas en la categoía  \\\"Inicio\\\" .';
$_MODULE['<{homefeatured}prestashop>homefeatured_3c230497560c52be92b93c65de9defc9'] = 'Número de productos mostrados';
$_MODULE['<{homefeatured}prestashop>homefeatured_5bc8290012fcc597689ef8959c2fc969'] = 'Número de productos mostrados en la página de inicio (por defecto: 10)';
$_MODULE['<{homefeatured}prestashop>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{homefeatured}prestashop>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Productos destacados';
$_MODULE['<{homefeatured}prestashop>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Más';
$_MODULE['<{homefeatured}prestashop>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{homefeatured}prestashop>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir al carrito';
$_MODULE['<{homefeatured}prestashop>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'No hay productos destacados';
