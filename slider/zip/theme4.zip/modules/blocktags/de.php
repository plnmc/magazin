<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Mehr darüber';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'noch keine Tags angegeben ';
$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Tags Block';
$_MODULE['<{blocktags}prestashop>blocktags_a332910d45d955dad6c84817fe478e95'] = 'Fügt einen Block mit einer Tag-Cloud hinzu';
$_MODULE['<{blocktags}prestashop>blocktags_4c1ef2cab0e711084a14f3d367a13c54'] = 'Sie müssen das Feld \"angezeigte Tags\" ausfüllen';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Ungültige Anzahl.';
$_MODULE['<{blocktags}prestashop>blocktags_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Bestätigung';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocktags}prestashop>blocktags_a2701a006c71c9097d80ea1ddaea8fa9'] = 'Angezeigte Tags';
$_MODULE['<{blocktags}prestashop>blocktags_ba1ebc23c8fd03e9b97da2f856f70765'] = 'Stellen Sie die Anzahl der Tags ein, die in diesem Block angezeigt werden sollen';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';

?>